
import Navigation from "../component/Navigation";
const Footer = () =>{
    return(
        <>
            <Navigation/>
        </>
    )
}

export default Footer;