
export const currencyFormater = new Intl.NumberFormat('de-US', { style: 'currency', currency: 'USD' });