import Header from "../component/Header";
import Navigation from "../component/Navigation";
const Signup = () =>{
    return(
        <>
            <Header/>
            <Navigation/>
            <div className="container">
            Signup 
            </div>
        </>
    )
}

export default Signup;