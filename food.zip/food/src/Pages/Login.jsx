import Header from "../component/Header";
import Navigation from "../component/Navigation";
const Login = () =>{
    return(
        <>
            <Header/>
            <Navigation/>
            <div className="container">
            Login 
            </div>
        </>
    )
}

export default Login;